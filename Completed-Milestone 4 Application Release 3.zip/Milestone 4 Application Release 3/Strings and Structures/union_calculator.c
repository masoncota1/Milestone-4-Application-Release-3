/* C calcutor program using union */
 
#include <stdio.h>
 
union calculator {    // Define the union named codewindow.
     int s;
     float k;
     char c;
};  // Declare three variables s, k and c of different data types.
  
int main() {
    union calculator u;
    int size = sizeof(u);    // Use the keyword sizeof() to find the size of a union and print the same.
 
    printf("The size of union used in the C program calculator is = %d\n", size);
 
    return 0;
}