#include <stdio.h>
 
struct calculator {    // Define the structure named calculator.
     int s;
     float k;
     char c;
};  // Declare three variables s, k and c of different data types.
  
int main() {
    struct calculator u;
    int size = sizeof(u);    // Use the keyword sizeof() to find the size of a structure and print the same.
 
    printf("The length of structures used in the C program calculator is = %d\n", size);
 
    return 0;
}